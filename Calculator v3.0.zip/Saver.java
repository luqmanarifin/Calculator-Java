public class Saver {
  public Saver() {
  
  }
  public void saveToFile() {
    System.out.println("Proses Save");
  }
}